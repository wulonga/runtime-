//
//  Animals.m
//  _objc_msgForward_demo
//
//  Created by luguobin on 15/9/21.
//  Copyright © 2015年 XS. All rights reserved.
//

#import "Animals.h"

@implementation Animals

//- (void)sel
//{
//    NSLog(@"Animal");
//}

@end
