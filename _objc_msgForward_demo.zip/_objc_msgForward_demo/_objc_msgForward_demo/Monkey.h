//
//  Monkey.h
//  _objc_msgForward_demo
//
//  Created by luguobin on 15/9/21.
//  Copyright © 2015年 XS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animals.h"

@interface Monkey : Animals

@end
